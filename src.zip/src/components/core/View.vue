<template>
      <v-content style="background: #f7f7f7;">
        <div id="core-view" style="height: 100%;">
          <v-fade-transition mode="out-in">
            <router-view />
          </v-fade-transition>
        </div>
      </v-content>
</template>

<script>
export default {
  metaInfo () {
    return {
      title: '量化大师'
    }
  }
}
</script>

<style>
#core-view {
  /* padding-bottom: 100px; */
}
</style>
