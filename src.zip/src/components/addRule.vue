<template>
	<v-card>
		<h5 class=" pa-5 ma-0 green white--text">
			<v-icon color="white" class="pr-5" @click="hideRule">mdi-arrow-left</v-icon>{{edit?'编辑规则':'添加规则'}}
		</h5>

		<v-expansion-panels v-model="type">
			<v-expansion-panel>
				<v-expansion-panel-header>现货</v-expansion-panel-header>
				<v-expansion-panel-content>
					<p>
						规则名称
						<input type="text" v-model="ruleName" class="nameStyle"/>
					</p>

					<v-sheet class="mx-auto">
						<v-slide-group v-model="activeRule" show-arrows center-active mandatory>
							<v-slide-item v-for="(n,index) in child" :key="n" v-slot:default="{ active }">
								<div class="d-flex justify-center align-center">
									<v-btn class="mx-2" :input-value="active" active-class="blue-grey darken-3 white--text" depressed rounded>
										{{ n }}

									</v-btn>
									<v-icon v-if="index!==child.length-1">mdi-arrow-right</v-icon>

									<!-- <v-divider  v-if="index!==child.length-1"></v-divider> -->
								</div>

							</v-slide-item>
						</v-slide-group>
					</v-sheet>

					<v-row>

						<v-col cols="12">
							<v-card outlined>
								<!-- <v-card dark> -->
								<v-card-text v-if="activeRule==0">
									<!-- <div class="headline mb-2">建仓规则</div> -->

									<v-row>
										<v-col cols="12" :lg="9" class="pb-0">
											<v-row>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text pr-3">买入跌幅</span>
														<input v-model="jData.R1" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">涨幅回调</span>
														<input v-model="jData.R2" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">单次买入金额</span>
														<input v-model="jData.R3" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">计价货币</span>
														<v-select class="ma-0 pt-0" style="width:120px;" 
														v-model="curcy" color="green" :items="currency"
														 item-text="value" item-value="id" label="计价货币" single-line></v-select>
													</div>
												</v-col>
											</v-row>

										</v-col>
										<v-col cols="12" class="pa-0"></v-col>
										<v-col cols="12" :lg="9">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon @click="allowJc">{{jData.R11 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>
													<span :style="{color:jData.R11?'black':'#BDBDBD'}">
														强制建仓
													</span>

												</v-col>
												<transition name="fade">
													<v-col cols="12" :lg="6" :md="6" :sm="6" :xs="12" v-if="jData.R11">
														<input v-model="jData.R12" type="number" min="1" :disabled="!jData.R11" class="xy-input" />
														<span class="black--text">分钟无仓强制建仓</span>
													</v-col>
												</transition>

											</v-row>
										</v-col>
										<v-col cols="12" class="pa-0"></v-col>
										<v-col cols="12" :lg="9">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon @click="allowSup">{{jData.R13 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>

													<span :style="{color:jData.R13?'black':'#BDBDBD'}">
														追涨
													</span>
												</v-col>


												<transition name="fade">
													<v-col cols="12" :lg="4" :md="6" :sm="6" :xs="12" v-if="jData.R13" key="1">
														<input v-model="jData.R14" type="number" min="1" :disabled="!jData.R13" class="xy-input" />
														<span class="black--text">分钟内上涨</span>
													</v-col>

												</transition>
												<transition name="fade">
													<v-col cols="12" :lg="4" :md="6" :sm="6" :xs="12" v-if="jData.R13" key="2">
														<input v-model="jData.R15" type="number" class="xy-input" min="0" :disabled="!jData.R13" />
														<span class="black--text">%则追涨建仓</span>

													</v-col>
												</transition>
												<transition name="fade">
													<v-col cols="12" :lg="4" :md="6" :sm="6" :xs="12" v-if="jData.R13" key="3">
														<input v-model="jData.R36" type="number" class="xy-input" min="1" :disabled="!jData.R13" />
														<span class="black--text">分钟延迟追涨(防插针)</span>

													</v-col>
												</transition>


											</v-row>
										</v-col>

									</v-row>
								</v-card-text>

								<v-card-text v-if="activeRule==1">

									<v-row>
										<v-col cols="12" :lg="6">
											<v-row>
												<v-col cols="12" :lg="3" :md="4" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text pr-3">卖出涨幅</span>
														<input v-model="jData.R4" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">涨幅回调</span>
														<input v-model="jData.R5" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">止损跌幅</span>
														<input v-model="jData.R6" type="number" class="xy-input" :step="0.1" min="0" />
													</div>
												</v-col>
											</v-row>

										</v-col>
										<v-col cols="12" class="pa-0"></v-col>
										<v-col cols="12" :lg="6">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon size="16" @click="allowPc">{{jData.R16 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>
													<span :style="{color:jData.R16?'black':'#BDBDBD'}">
														杀跌平仓
													</span>

												</v-col>
												<transition name="fade">
													<v-col cols="12" :lg="6" :md="6" :sm="6" :xs="12" v-if="jData.R16">
														<input v-model="jData.R17" type="number" min="1" :disabled="!jData.R16" class="xy-input" />
														<span class="black--text">分钟内下跌</span>

													</v-col>
												</transition>


												<transition name="fade">
													<v-col cols="12" :lg="6" :md="6" :sm="6" :xs="12" v-if="jData.R16">
														<input v-model="jData.R18" type="number" class="xy-input" min="0" :disabled="!jData.R16" />
														<span class="black--text">%则杀跌平仓</span>

													</v-col>
												</transition>

											</v-row>
										</v-col>
									</v-row>

								</v-card-text>

								<v-card-text v-if="activeRule==2">
									<!-- <div class="headline mb-2">补仓规则</div> -->
									<v-row>
										<v-col cols="12" :lg="9" class="pb-0">
											<v-row>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text pr-3">单次补仓跌幅(%)</span>
														<input v-model="jData.R7" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">补仓回调</span>
														<input v-model="jData.R10" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">单次补仓金额</span>
														<input v-model="jData.R9" type="number" class="xy-input" :step="0.01" min="0" />
													</div>
												</v-col>
												<v-col cols="12" :lg="3" :md="3" :sm="3" :xs="12">
													<div class=" d-flex align-start justify-center flex-column">
														<span class="black--text  pr-3">补仓次数</span>
														<input v-model="jData.R8" type="number" class="xy-input" min="0" />
													</div>
												</v-col>
											</v-row>

										</v-col>
										<v-col cols="12" class="pa-0"></v-col>

										<v-col cols="8" :lg="6">
											<v-row>
												<v-col cols="12" :lg="6" :md="6" :sm="6" :xs="12">
													<v-checkbox v-model="jData.R19" label="补仓单独卖出"></v-checkbox>
												</v-col>
												<v-col cols="12" :lg="6" :md="6" :sm="6" :xs="12">
													<v-checkbox :disabled="!jData.R19" v-model="jData.R20" label="补单可进行补仓"></v-checkbox>
												</v-col>
											</v-row>
										</v-col>

									</v-row>
								</v-card-text>

								<v-card-text v-if="activeRule==3">
									<!-- 							<div class="headline mb-2">其他规则</div> -->
									<v-row>
										<v-col cols="12" class="pb-0">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon @click="allowQtBc">{{jData.R26 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>
													启用

												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<input v-model="jData.R27" type="number" :class="[jData.R26?'xy-input':'xy-input-disable']" min="1"
													 :disabled="!jData.R26" />
													<span :style="{color:jData.R26?'black':'#BDBDBD'}">分钟内下跌</span>
												</v-col>

												<v-col cols="12" :lg="3" :md="3" :sm="4" :xs="12">
													<input v-model="jData.R28" type="number" :class="[jData.R26?'xy-input':'xy-input-disable']" min="0"
													 :disabled="!jData.R26" />
													<span :style="{color:jData.R26?'black':'#BDBDBD'}">%时</span>
												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<span :style="{color:jData.R26?'black':'#BDBDBD'}">补仓比例</span>
														<input v-model="jData.R29" type="number" :class="[jData.R26?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R26" />
														<span :style="{color:jData.R26?'black':'#BDBDBD'}">%</span>
													</v-flex>
												</v-col>
												<v-col cols="12" :lg="3" :md="5" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<input v-model="jData.R30" type="number" :class="[jData.R26?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R26" />
														<span :style="{color:jData.R26?'black':'#BDBDBD'}">分钟后恢复数值</span>
													</v-flex>
												</v-col>
											</v-row>

										</v-col>

										<v-col cols="12" class="pb-0">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon @click="allowQtZs">{{jData.R21 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>
													启用

												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<input v-model="jData.R22" type="number" :class="[jData.R21?'xy-input':'xy-input-disable']" min="1"
													 :disabled="!jData.R21" />
													<span :style="{color:jData.R21?'black':'#BDBDBD'}">分钟内下跌</span>
												</v-col>

												<v-col cols="12" :lg="3" :md="3" :sm="4" :xs="12">
													<input v-model="jData.R23" type="number" :class="[jData.R21?'xy-input':'xy-input-disable']" min="0"
													 :disabled="!jData.R21" />
													<span :style="{color:jData.R21?'black':'#BDBDBD'}">%时</span>
												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<span :style="{color:jData.R21?'black':'#BDBDBD'}">止损比例</span>
														<input v-model="jData.R24" type="number" :class="[jData.R21?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R21" />
														<span :style="{color:jData.R21?'black':'#BDBDBD'}">%</span>
													</v-flex>
												</v-col>
												<v-col cols="12" :lg="3" :md="5" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<input v-model="jData.R25" type="number" :class="[jData.R21?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R21" />
														<span :style="{color:jData.R21?'black':'#BDBDBD'}">分钟后恢复数值</span>
													</v-flex>
												</v-col>
											</v-row>

										</v-col>

										<v-col cols="12" class="pb-0">
											<v-row>
												<v-col cols="12" class="pb-0">
													<v-icon @click="allowQtJc">{{jData.R31 ? 'mdi-check-box-outline' : 'mdi-square-outline'}}</v-icon>
													启用

												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<input v-model="jData.R32" type="number" :class="[jData.R31?'xy-input':'xy-input-disable']" min="1"
													 :disabled="!jData.R31" />
													<span :style="{color:jData.R31?'black':'#BDBDBD'}">分钟内下跌</span>
												</v-col>

												<v-col cols="12" :lg="3" :md="3" :sm="4" :xs="12">
													<input v-model="jData.R33" type="number" :class="[jData.R31?'xy-input':'xy-input-disable']" min="0"
													 :disabled="!jData.R31" />
													<span :style="{color:jData.R31?'black':'#BDBDBD'}">%时</span>
												</v-col>
												<v-col cols="12" :lg="3" :md="4" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<span :style="{color:jData.R31?'black':'#BDBDBD'}">建仓比例</span>
														<input v-model="jData.R34" type="number" :class="[jData.R31?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R31" />
														<span :style="{color:jData.R31?'black':'#BDBDBD'}">%</span>
													</v-flex>
												</v-col>
												<v-col cols="12" :lg="3" :md="5" :sm="6" :xs="12">
													<v-flex class="d-flex align-center justify-start">
														<input v-model="jData.R35" type="number" :class="[jData.R31?'xy-input':'xy-input-disable']" min="1"
														 :disabled="!jData.R31" />
														<span :style="{color:jData.R31?'black':'#BDBDBD'}">分钟后恢复数值</span>
													</v-flex>
												</v-col>
											</v-row>

										</v-col>

									</v-row>
								</v-card-text>

								<p v-if="myMsg.show" class="red--text px-6 ma-0">
									{{myMsg.text}}
								</p>
								<v-card-actions>
									<v-btn @click="activeRule--" v-if="activeRule>0">上一个</v-btn>

									<v-btn color="primary" v-if="activeRule == child.length-1" @click="postRule">提交</v-btn>
									<v-btn @click="validateData()" color="primary" v-else>填写完成,下一个</v-btn>
								</v-card-actions>
							</v-card>
						</v-col>

					</v-row>


				</v-expansion-panel-content>
			</v-expansion-panel>

			<!-- <v-expansion-panel>
				<v-expansion-panel-header>合约</v-expansion-panel-header>
				<v-expansion-panel-content>
					暂无
				</v-expansion-panel-content>
			</v-expansion-panel> -->

		</v-expansion-panels>
	</v-card>
</template>


<script>
	import {
		mapActions
	} from 'vuex';
	import Utils from '@/plugins/cryAes.js'
	import Valid from '@/plugins/validate.js'
	export default {
		data() {
			return {
				ajaxObj:{},//要提交的规则数据
				
				ruleName: '', //规则名称
				jData: { //建仓
					R1: 0, //买入跌幅
					R3: 1, //单次买入金额
					R2: 0, //跌幅回调
					R54: null, //计价货币
					R11: false, //允许强制建仓
					R12: 0, //强制建仓
					R13: false, //允许
					R14: 1, //分钟内上涨
					R15: 0, //追涨建仓
					R36: 1, //防插针

					R7: 0, //单次补仓跌幅
					R10: 0, //补仓回调
					R9: 0, //单次补仓金额
					R8: 0, //补仓
					R19: false, //补仓单独卖出
					R20: false, //补单可进行补仓

					R4: 0, //卖出涨幅
					R5: 0, //涨幅回调
					R6: 0, //止损跌幅
					R16: false, //允许分钟内下跌
					R17: 0, //分钟内下跌
					R18: 0, //杀跌平仓

					R26: false, //允许补仓
					R27: 0, //分钟内下跌
					R28: 0, //时
					R29: 0, //补仓比例更改为
					R30: 0, //分钟后回复数值
					R21: false, //允许止损
					R22: 0,
					R23: 0,
					R24: 0,
					R25: 0,
					R31: false, //允许建仓
					R32: 0,
					R33: 0,
					R34: 0,
					R35: 0
				},

				activeRule: 0,

				curcy: 1, //当前的R54(货币)

				myMsg: {
					show: false,
					text: '错误'
				},

				currency: [{
						id: 1,
						value: 'USDT'
					},
					{
						id: 2,
						value: 'ETH'
					},
					{
						id: 3,
						value: 'BTC'
					},
				],

				child: ['建仓规则', '平仓规则', '补仓规则', '其他规则'],

				type: 0
			}
		},
		props: {
			ruleObj: {
				type: Object,
				default: () => ({})
			},
			edit: {
				type: Boolean,
				default: false
			}
		},
		watch: {
			edit: {
				handler: 'transPropsData',
				immediate: true
			},
			wssData:{
				handler(nV,oV){
					this.getMessage();
				},
				deep:true
			}
		},
		
		computed:{
			wssData(){//wss传递的消息
				return this.$store.state.collocationList;
			}
		},
		
		mounted() {
			
		},

		methods: {
			validateData() { //点击下一步的时候验证
				this.myMsg = {
					show: false,
					text: ''
				};
				switch (this.activeRule) {
					case 0:
						this.jcRules();
						break;
					case 1:
						this.pcRules();
						break;
					case 2:
						this.bcRules();
						break;
					default:
						break;
				}
			},

			pcRules() { //平仓规则校验
				if (Valid.nonzero(this.jData.R4)) {
					this.myMsg = {
						show: true,
						text: '卖出涨幅必须大于0'
					};
				} else if (Valid.nonzero(this.jData.R6)) {
					this.myMsg = {
						show: true,
						text: '止损跌幅必须大于0'
					};
				} else {
					this.activeRule++;
				}


			},
			bcRules() { //补仓规则校验
				if (Valid.nonzero(this.jData.R7)) {

					this.myMsg = {
						show: true,
						text: '单次补仓涨幅必须大于0'
					};

				} else if (Valid.nonzero(this.jData.R9)) {

					this.myMsg = {
						show: true,
						text: '单次补仓金额必须大于0'
					};
				} else {
					this.activeRule++;
				}

			},


			jcRules() { //建仓规则校验
				if (Valid.isEmpty(this.ruleName)) {
					this.myMsg = {
						show: true,
						text: '规则名称不可为空'
					};
				} else if (Valid.nonzero(this.jData.R1)) {
					this.myMsg = {
						show: true,
						text: '买入跌幅必须大于0'
					};
				} else if (Valid.nonzero(this.jData.R3)) {

					this.myMsg = {
						show: true,
						text: '单次买入金额必须大于0'
					};
				} else {
					this.activeRule++;
				}

			},

			transPropsData() { //编辑初始化对数据进行转换
				if (this.edit) {
					let item = JSON.parse(JSON.stringify(this.ruleObj));
					this.curcy = Number(item.R54);
					this.ruleName = item.R0 ? this.unescapeF(item.R0): '';
					item.R11 = item.R11 == 1 ? true : false;
					item.R13 = item.R13 == 1 ? true : false;
					item.R19 = item.R19 == 1 ? true : false;
					item.R16 = item.R16 == 1 ? true : false;
					item.R20 = item.R20 == 1 ? true : false;
					item.R21 = item.R21 == 1 ? true : false;
					item.R26 = item.R26 == 1 ? true : false;
					item.R31 = item.R31 == 1 ? true : false;

					this.jData = Object.assign({}, this.jData, item);
				}

			},

			selectCurrency(e) { //选择计价货币
				this.jData.R54 = e;
			},

			...mapActions(['changeLay', 'changeSnack']),

			hideRule() {
				this.$emit('hideRule');
			},
			allowJc() { //是否强制建仓

				this.jData.R11 = !this.jData.R11;
				if (!this.jData.R11) { //没被选中
					this.jData.R12 = 0;
				}
			},

			allowSup() {
				this.jData.R13 = !this.jData.R13;
				if (!this.jData.R13) {
					this.jData.R14 = 0;
					this.jData.R15 = 0;
					this.jData.R36 = 0;
				}
			},

			allowPc() { //允许-平仓
				this.jData.R16 = !this.jData.R16;
				if (!this.jData.R16) {
					this.jData.R17 = 0;
					this.jData.R18 = 0;
				}
			},

			allowQtBc() { //其他规则-启用补仓

				this.jData.R26 = !this.jData.R26;
				if (!this.jData.R26) {
					this.jData.R27 = 0;
					this.jData.R28 = 0;
					this.jData.R29 = 0;
					this.jData.R30 = 0;

				}

			},

			allowQtZs() { //其他规则-启用止损
				this.jData.R21 = !this.jData.R21;
				if (!this.jData.R21) {
					this.jData.R22 = 0;
					this.jData.R23 = 0;
					this.jData.R24 = 0;
					this.jData.R25 = 0;

				}

			},

			allowQtJc() { //其他规则-启用建仓
				this.jData.R31 = !this.jData.R31;
				if (!this.jData.R31) {
					this.jData.R32 = 0;
					this.jData.R33 = 0;
					this.jData.R34 = 0;
					this.jData.R35 = 0;

				}
			},
			
			unescapeF(str){//unicode=>文字
				return unescape(str.replace(/\\/g, "%"))
			},


			charToUnicode(str) {
				let res = [];
				    for (let i = 0; i < str.length; i++) {
				        res[i] = ( "00" + str.charCodeAt(i).toString(16) ).slice(-4);
				    }
				    return "%u" + res.join("%u");
			},
			
			getMessage(){//wss传递的消息
				let result = this.wssData;
				switch (result.code){
					case 20013://客户端在线
					this.wssSave();
						break;	
						
					default:
						break;
				}
					
			},
			
			wssSave(){
				let json = JSON.stringify({
					code: 1006
				});
								
				this.$sock.websocketsend(json);
			},
			
			postRule() { //提交规则
				if (this.ruleName !== '') { //规则名称不能为空
					let list = this.jData;
					list.R54 = this.curcy;
					let title = this.ruleName.trimStart().trimEnd();
					list.R0 = this.charToUnicode(title);
					list.R11 = list.R11 ? 1 : 0;
					list.R13 = list.R13 ? 1 : 0;
					list.R19 = list.R19 ? 1 : 0;
					list.R16 = list.R16 ? 1 : 0;
					list.R20 = list.R20 ? 1 : 0;
					list.R21 = list.R21 ? 1 : 0;
					list.R26 = list.R26 ? 1 : 0;
					list.R31 = list.R31 ? 1 : 0;
					
					for(let i in list){ //数字转成了字符
					  if(typeof(list[i])=='number'){
					  	list[i] = list[i].toString();
					  }
					}
					
					let obj = {
						name: title,
						data: Utils.encrypt(JSON.stringify(list))
					};
					
					console.log(list)

					this.edit?obj.id = list.id:'';
					
					let url = this.edit?'/EasWebUser/changeRule':'/EasWebUser/addRule';
					
					$ax.getAjaxData(url, obj, (res) => {
						this.changeLay(false);
						if (res.code == 1) {
							let msg = {
								state: true,
								errorText: {
									type: 'green',
									text: this.edit ? '编辑成功' : '添加成功'
								}
							}
							this.changeSnack(msg);
							
							let state = this.$sock.lookState();
							
							state==-1?this.$sock.initWebSocket():this.wssSave();
							
							sessionStorage.removeItem('collocation'); //清空缓存里的rule/api
					
							Object.assign(this.$data, this.$options.data());
					
							this.hideRule();
						}
					}, {
						hasToken: true
					});
					
					
					
				} else {
					this.myMsg = {
						show: true,
						text: '规则名称有误，请检查'
					};
				}

			}

		}
	}
</script>

<style scoped="scoped">
	.xy-select {
		width: 100px;
		border: 1px solid;
		border-radius: 3px;
		background: none;
		padding: 4px;
	}

	.xy-select:focus {
		outline: 0;
		border: 1px solid #4caf50;
		border-radius: 5px;
	}

	.xy-options {
		padding: 5px 3px;
	}

	.xy-options:hover {
		background: #4caf50;
	}

	.nameStyle {
		outline: 0;
		max-width: 200px;
		padding: 3px 3px 3px 5px;
		border-radius: 3px;
		border: 1px solid;
	}

	.fade-enter-active,
	.fade-leave-active {
		transition: opacity .5s
	}

	.fade-enter,
	.fade-leave-active {
		opacity: 0
	}
</style>
